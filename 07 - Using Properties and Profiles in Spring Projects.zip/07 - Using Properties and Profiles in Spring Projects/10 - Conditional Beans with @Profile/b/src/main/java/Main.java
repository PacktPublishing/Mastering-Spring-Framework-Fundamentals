public class Main {
    public static void main(String[] args) {
        int i=30;
        while (--i >= 15) {
            System.out.println("Looping");
        }
    }
}
