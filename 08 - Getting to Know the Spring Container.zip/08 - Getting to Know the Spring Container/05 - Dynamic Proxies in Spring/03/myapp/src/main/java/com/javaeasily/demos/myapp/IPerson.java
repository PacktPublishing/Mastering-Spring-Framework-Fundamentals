package com.javaeasily.demos.myapp;

public interface IPerson {
    void greet();
}
