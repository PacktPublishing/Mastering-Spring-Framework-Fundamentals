package com.javaeasily.demos.myapp;

public class PersonImpl implements Person {

    public void greet() {
        System.out.println("Hello there!");
    }

}
