package com.zention.training.demos.myapp.business;

import org.springframework.stereotype.Service;

@Service
public class AnotherServiceImpl implements MyService {

    @Override
    public void doBusinessLogic() {
        System.out.println("Doing business logic sligbhtly differently!");
    }

}
