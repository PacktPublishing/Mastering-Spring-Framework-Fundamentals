package com.zention.training.demos.myapp;

public class MyService {

    public void doSomething() {
        System.out.println("Doing something important!");
    }

}
