package com.javaeasily.demos.myapp;

public class Person {

    public void greet() {
        System.out.println("Hello there!");
    }

}
