package com.javaeasily.demos.myapp;

public class Person implements IPerson {

    public void greet() {
        System.out.println("Hello there!");
    }

}
