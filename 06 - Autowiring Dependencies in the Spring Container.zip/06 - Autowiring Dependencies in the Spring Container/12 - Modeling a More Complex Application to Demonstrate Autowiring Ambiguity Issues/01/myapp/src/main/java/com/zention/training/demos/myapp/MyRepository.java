package com.zention.training.demos.myapp;

public interface MyRepository {
    void doQuery();
}
